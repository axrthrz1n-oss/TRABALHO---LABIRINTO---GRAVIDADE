# Labirinto Giratório – M2

Equipe: Arthur Ferraz de Aquino & Vicenzo Roman Radin
Prof. Tiago Felski – Algoritmos e Programação II (UNIVALI)

## (a) Versão
Linux (`termios.h` / `unistd.h`). Compilar: `g++ -Wall -o labirinto labirinto.cpp` e rodar `./labirinto` na pasta dos arquivos.
Extensões `.txt` no lugar de `.csv`/`.sol` porque o OnlineGDB tenta compilar qualquer outra extensão (erro do linker). O formato interno é o do enunciado. Também roda no OnlineGDB: quando a entrada não é um terminal, cada tecla é digitada seguida de Enter (use **X** no lugar de ESC).

## Arquivos
`mapaN.txt` (cenário, formato CSV), `mapaN_sol.txt` (solução), `jogo_salvo.txt` e `recordes.txt` (criados pelo jogo).
Mapas: 1 Tampão de pedra (11x11, 1 giro) · 2 A porta que some (11x11, 1 giro) · 3 Vai e volta (13x13, 2 giros) · 4 Três portas (15x15, 3 giros) · 5 Torre final (17x17, 3 giros).

## (b) Formato do jogo_salvo.txt (uma informação por linha)
1. número do mapa
2. n (dimensão)
3. orientação (0 a 3)
4. movimentos
5. rotações
6. código da célula que está sob o jogador (0 vazio, 4 alavanca, 5 saída, 6/7 porta)
7. título do mapa
8. n linhas do cenário atual (n códigos separados por vírgula; o jogador aparece como 2)

Arquivo ausente, vazio ou corrompido é tratado como "sem jogo salvo". O jogo é gravado só ao sair (ESC/X) e apagado ao vencer.

## (c) Antes/depois (confira as assinaturas da M1 no histórico, tag `m1`)
| Função | M1 | M2 | Motivo |
|---|---|---|---|
| MoveJogador | 8 parâmetros soltos (mapa, px, py, celulaSobJogador, tecla, orientacao, venceu, moveu) | `int MoveJogador(Jogo &j, char tecla)` | estado dentro da struct, resultado por retorno |
| ProcessaRotacao | 7 parâmetros e imprimia mensagem | `int ProcessaRotacao(Jogo &j, char tecla)` | regra não imprime; a tela trata `RES_SEM_ALAVANCA` |
| CelulaSustentaBloco | matriz, linha, coluna, orientação (não usada) | `bool CelulaSustentaBloco(int valor)` | só recebe o que precisa |
| CelulaAtravessavel | matriz inteira | `bool CelulaAtravessavel(int valor, int orientacao)` | idem |
| LocalizaJogador | matriz + linha + coluna por referência | `void LocalizaJogador(Jogo &j)` | grava em `j.jogador` |
| GiraDireita/GiraEsquerda | duas matrizes TAM x TAM | `void GiraDireita(Jogo &j)` | n variável, uma só struct |
| JogaFase | 9 parâmetros | `void JogaFase(Jogo &j)` | idem |

## (d) Defeitos da M1 corrigidos
- `srand` nunca era chamado (aleatório repetia sempre).
- Mensagens impressas dentro de função de regra (`ProcessaRotacao`).
- Parâmetro `orientacao` sem uso em `CelulaSustentaBloco`.
- Código assumia tamanho fixo 11x11 (`#define TAM`).
- *(acrescentar aqui os defeitos apontados na correção da M1 pelo professor)*

## (e) Decisões de projeto
- **Struct por valor ou referência?** Referência nas funções que alteram o jogo (custo zero, altera o original). Por valor só em `MapaEstavel`, onde a cópia é o objetivo: a gravidade roda na cópia e o original fica intacto (copiar ~1,7 KB é barato).
- **Posição do jogador redundante?** Sim. Guardamos `j.jogador` por desempenho, mas `LocalizaJogador` é chamada após girar e ao carregar, para não haver inconsistência com a matriz.
- **O que é gravado no salvo?** Tudo que não dá para recalcular: cenário atual, orientação, contadores, célula sob o jogador. Posição é recalculada. Grava só ao sair com ESC (nenhum custo durante o jogo e o spec pede isso).
- **Mesmas regras ao jogar e reproduzir:** ambos chamam `ProcessaTecla`.
- **Desempate do ranking:** menos movimentos, depois menos rotações (rotação é a ação mais "cara" do jogo).
- **Separação:** regras (não imprimem/não leem arquivo), arquivos (não imprimem), tela (só imprime). `ListaMapas` e `VerificaTodos` orquestram.
- Nomes dos arquivos ficam em constantes no topo (`EXT_MAPA`, `ARQ_SALVO`, `ARQ_RECORDES`), fáceis de trocar para `.txt`.

## (f) Desafios extras
Nenhum.
